/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package toystopinventorymanagementsystem;
import java.io.*;
/**
 *
 * @author Faaiz
 */
import java.io.*;
public class Serialize {
   ToyStopService s=new ToyStopService();
   Serialize(ToyStopService s)
   {
       this.s=s;
   }
   public void ser() {
      
      
      try {
         FileOutputStream fileOut =
         new FileOutputStream("tmp/employee.ser");
         ObjectOutputStream out = new ObjectOutputStream(fileOut);
         out.writeObject(s);
         out.close();
         fileOut.close();
         System.out.printf("Serialized data is saved in /tmp/stores.ser");
      }catch(IOException i) {
         i.printStackTrace();
      }
   }
}