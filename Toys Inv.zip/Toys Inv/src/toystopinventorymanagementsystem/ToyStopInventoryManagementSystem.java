package toystopinventorymanagementsystem;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author Fahad Satti
 */
public class ToyStopInventoryManagementSystem implements java.io.Serializable {
    
    ToyStopService tsService = new ToyStopService();
    public void init(){
        
        tsService.initEmployees();
        tsService.initStores();
        tsService.initToys();
        System.out.println("Init complete");
    }
    public void storeData()
    {
        Serialize s= new Serialize(this.tsService);
        s.ser();
    }
     public void restoreData()
    {
        Deserialize d= new Deserialize();
        d.des();
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        boolean exit=false;
       
        //Serialize s= new Serialize(this.tsService);
        ToyStopInventoryManagementSystem tsims = new ToyStopInventoryManagementSystem();
        tsims.init();
        int s=0;
        while(!exit)
        {
            
            tsims.showMenu();
            switch(s)
            {
                case 0:
                    tsims.storeData();
                    break;
                case 1:
                    tsims.printAll();
                case 2:
                    System.out.println(tsims.tsService.addStore()+" added");
                case 3:
                    System.out.println(tsims.tsService.addEmployee()+" added");
                case 4:
                     System.out.println(tsims.tsService.addToy()+" added");
                case 5:
                     tsims.tsService.AssignEmploys();
                default :
                     System.out.println("Select right option.");
            }
            Scanner reader = new Scanner(System.in); 
            s = reader.nextInt();
        }
        //load previous data
        //tsims.loadData();
        
        //tsims.showMenu();
        
        
    }

    private void loadData() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void showMenu() {
        System.out.println("Welcome to Toy Stop Inventory Management System");
        System.out.println("Enter 1 to show all data");
        System.out.println("Enter 2 to add a new Store");
        System.out.println("Enter 3 to add a new Employee");
        System.out.println("Enter 4 to add a new Toy");
        System.out.println("Enter 5 to assign employs");
        System.out.println("Enter 0 to save state");
    }

    private void printAll() {
        //Serialize s= new Serialize(this.tsService);
        //s.ser();
     //  Deserialize d= new Deserialize();
       // d.des();
       System.out.println(this.tsService.stores);
    }
    
}
