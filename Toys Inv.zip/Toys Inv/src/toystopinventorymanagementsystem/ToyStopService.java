
package toystopinventorymanagementsystem;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Fahad Satti
 */
public class ToyStopService implements java.io.Serializable {
    ArrayList<Employee> employees = new ArrayList<>();
    ArrayList<Store> stores = new ArrayList<>();
        
    public void initEmployees(){
        //Create a List of first 200 Employees
        for(int i=0; i<200; i++){
            Employee myEmployee = new Employee();
            myEmployee.setUID(i);
            myEmployee.setRandomName();
            myEmployee.setEmail(myEmployee.getName()+"@toystop.org");
            
            employees.add(myEmployee);
        }
    }
    
    public void initStores(){
        //Create a List of Stores in a region
        for(int i=0; i<100; i++){
            Store myStore = new Store();
            myStore.setUID(Util.getSaltNum(-1));
            myStore.addRandomEmployees(employees);
            stores.add(myStore);
            myStore.setAddress(Util.getSaltAlphaNumString());
            myStore.setContactNo("+92"+Util.getSaltNum(9));
            Email storeEmail = new Email();
            storeEmail.setEmailAddress(myStore.getUID()+"@toystop.org");
            myStore.setEmail(storeEmail);
            
        }
        
    }
    public boolean AssignEmploys()
    {
        while (!employees.isEmpty())
        {
            for(Store t:stores)
            {
                if(!employees.isEmpty())
                    t.addRandomEmployees(employees);
                else
                    return true;
            }
        }
        return true;
    }
    
    public void initToys(){
        //Add Toys in random stores
        for(int i=0; i<200000; i++){
            Toy newToy = new Toy();
            newToy.setUID(Util.getSaltNum(-1));
            newToy.setMinAge(Util.getSaltNum(1));
            newToy.setMaxAge(Util.getSaltNum(18));
            newToy.setPrice(Util.getSaltNum(1000));
            newToy.setName(Util.getSaltAlphaString());
            newToy.setAddedOn(LocalDateTime.now());
            
            Random randStore = new Random();
            int index = randStore.nextInt(stores.size());
            Store selectedStore = (Store)stores.get(index);
            selectedStore.addToy(newToy);
            
        }
    }
    public int addToy()
    {
        Toy newToy = new Toy();
        newToy.setUID(Util.getSaltNum(-1));
        Scanner reader = new Scanner(System.in);  // Reading from System.in
        System.out.println("Enter Minimum Age Limit: ");
        int mA = reader.nextInt();
        newToy.setMinAge(mA);
        System.out.println("Enter Maximmum Age Limit: ");
        int  MA= reader.nextInt();
        newToy.setMaxAge(MA);
        System.out.println("Enter Price: ");
        int  p= reader.nextInt();
        newToy.setPrice(p);
        System.out.println("Enter name of toy: ");
        String name = reader.next();
        newToy.setName(name);
        newToy.setAddedOn(LocalDateTime.now());
        System.out.println("Enter Store Uid u want to enter in : ");
        int index = reader.nextInt();
        Store selectedStore = (Store)stores.get(index);
        selectedStore.addToy(newToy);
        return newToy.getUID();
    }
    
    //Only creates a new employee and returns the UID
    public int addEmployee(){
            Employee myEmployee = new Employee();
            
            myEmployee.setRandomName();
            myEmployee.setEmail(myEmployee.getName()+"@toystop.org");
            myEmployee.setUID(employees.size()+1);
            employees.add(myEmployee);
            return myEmployee.getUID();
    }
    
    //Creates a new store

    public int addStore(){
            Store myStore = new Store();
            myStore.setUID(Util.getSaltNum(-1));
            //This will assign any new employees or the ones remaining after previous store insertions.
            myStore.addRandomEmployees(employees);
            Scanner reader = new Scanner(System.in);  // Reading from System.in
            System.out.println("Enter Address of store: ");
            String add = reader.next();
            myStore.setAddress(add);
           // Reading from System.in
            System.out.println("Enter Address of store: ");
            int phone = reader.nextInt();
            myStore.setContactNo("+92"+phone);
            Email storeEmail = new Email();
            storeEmail.setEmailAddress(myStore.getUID()+"@toystop.org");
            myStore.setEmail(storeEmail);
            stores.add(myStore);
            return myStore.getUID();
    }
}
