/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package toystopinventorymanagementsystem;

import java.io.*;


/**
 *
 * @author Faaiz
 */
public class Deserialize {

   public void des() {
      ToyStopService s = null;
      try {
         FileInputStream fileIn = new FileInputStream("tmp/employee.ser");
         ObjectInputStream in = new ObjectInputStream(fileIn);
         s = (ToyStopService) in.readObject();
         in.close();
         fileIn.close();
      }catch(IOException i) {
         i.printStackTrace();
         return;
      }catch(ClassNotFoundException c) {
         System.out.println("Employee class not found");
         c.printStackTrace();
         return;
      }
      
      System.out.println(s.stores);
     
   }
}