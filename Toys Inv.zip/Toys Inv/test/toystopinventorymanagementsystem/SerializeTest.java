/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package toystopinventorymanagementsystem;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Faaiz
 */
public class SerializeTest {
    
    public SerializeTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of ser method, of class Serialize.
     */
    @Test
    public void testSer() {
        System.out.println("ser");
        ToyStopService ts=new ToyStopService();
        Serialize instance = new Serialize(ts) ;
        instance.ser();
        // TODO review the generated test code and remove the default call to fail.

    }
    
}
